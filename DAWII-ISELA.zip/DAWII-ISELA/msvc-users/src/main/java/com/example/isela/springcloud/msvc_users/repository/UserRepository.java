package com.example.isela.springcloud.msvc_users.repository;

import org.springframework.data.repository.CrudRepository;
import com.example.isela.springcloud.msvc_users.entity.User;

public interface UserRepository extends CrudRepository<User, Long> {
}
