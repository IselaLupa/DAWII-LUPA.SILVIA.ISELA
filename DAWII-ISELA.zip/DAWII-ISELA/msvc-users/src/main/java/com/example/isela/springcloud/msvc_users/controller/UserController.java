package com.example.isela.springcloud.msvc_users.controller;

import com.example.isela.springcloud.msvc_users.entity.User;
import com.example.isela.springcloud.msvc_users.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    // Obtener todos los usuarios
    @GetMapping
    public List<User> getAllUsers() {
        return userService.findAll();
    }

    // Obtener usuario por ID
    @GetMapping("/{id}")
    public User getUserById(@PathVariable Long id) {
        return userService.findById(id).orElse(null); // Devuelve null si no se encuentra el usuario
    }
}