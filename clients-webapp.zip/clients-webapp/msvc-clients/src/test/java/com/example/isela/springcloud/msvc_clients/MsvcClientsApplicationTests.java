package com.example.isela.springcloud.msvc_clients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcClientsApplicationTests {

	@Test
	void contextLoads() {
	}

}
